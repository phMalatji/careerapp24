export const PROVINCES = [
    "Gauteng", "Western Cape", "Limpopo", "KZN", "Mpumalanga", "Eastern Cape", "Northen Cape","Free State"
]; 

export const SECTORS = [
"FINANCE", "IT", "MARKETING", "RETAIL", "MINING", "ENGINEERING"
];