export const menuItems : string[] = [
    "Home", "Contact Us "
];