export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDDxT8MgBNcPiSWJRL10IFSpYqm5QEO6mI",
    authDomain: "fbapp-e0ad0.firebaseapp.com",
    databaseURL: "https://fbapp-e0ad0.firebaseio.com",
    projectId: "fbapp-e0ad0",
    storageBucket: "fbapp-e0ad0.appspot.com",
    messagingSenderId: "1047186289052"
  }
};
